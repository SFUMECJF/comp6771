#include <string>

#include "catch2/catch.hpp"

TEST_CASE("sort3 for integers") {}
TEST_CASE("sort3 for std::string") {}
